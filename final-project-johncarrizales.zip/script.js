const audioPlayer = document.getElementById('audioPlayer');
const albumCoverElement = document.getElementById('albumCover');
const songTitleElement = document.getElementById('songTitle');
const songArtistElement = document.getElementById('songArtist');
const seekSlider = document.querySelector('.seek-slider');
const volumeSlider = document.querySelector('.volume-slider');

let currentTrackIndex = 0;
let currentVolume = 50; // Add a tracking variable for volume

const playlist = [
    { title: 'Chase', artist: 'Batta', file: '../final project/music/chase.mp3', cover: '../final project/images/chase.png' },
    { title: 'Never Ending Summer', artist: 'Omega Tribe', file: '../final project/music/NEVER ENDING SUMMER.mp3', cover: '../final project/images/summer.png' },
    { title: 'All off', artist: 'refrain boy', file: '../final project/music/All off.mp3', cover: '../final project/images/all.jpg' },
    { title: 'Remeber', artist: 'Flow', file: '../final project/music/Flow.mp3', cover: '../final project/images/flow.png' },
];

function loadTrack(index) {
    const track = playlist[index];
    audioPlayer.src = track.file;
    albumCoverElement.src = track.cover;
    songTitleElement.textContent = track.title;
    songArtistElement.textContent = track.artist;
}

function playPause() {
    if (audioPlayer.paused) {
        audioPlayer.play();
    } else {
        audioPlayer.pause();
    }
}

function togglePlayPause() {
    const playBtn = document.querySelector('.play-btn');
    playPause();
    playBtn.textContent = audioPlayer.paused ? '►' : '❚❚';
}

function nextTrack() {
    currentTrackIndex = (currentTrackIndex + 1) % playlist.length;
    loadTrack(currentTrackIndex);
    audioPlayer.play();
}

function prevTrack() {
    currentTrackIndex = (currentTrackIndex - 1 + playlist.length) % playlist.length;
    loadTrack(currentTrackIndex);
    audioPlayer.play();
}

function seekTrack() {
    const seekValue = seekSlider.value;
    const seekToTime = (seekValue / 100) * audioPlayer.duration;
    audioPlayer.currentTime = seekToTime;
}

function setVolume() {
    const volumeValue = volumeSlider.value / 100;
    audioPlayer.volume = volumeValue;
    currentVolume = Math.round(volumeValue * 100); // Update the tracking variable
    updateVolumeDisplay(); // Call the function to update volume display
}

function updateVolumeDisplay() {
    // You can add code here to update the UI with the current volume (e.g., a volume icon)
    console.log(`Current Volume: ${currentVolume}`);
}

function updateTime() {
    const currentTime = formatTime(audioPlayer.currentTime);
    const duration = formatTime(audioPlayer.duration);
    seekSlider.value = (audioPlayer.currentTime / audioPlayer.duration) * 100;

    // Call the function to update time display
    updateTimeDisplay(currentTime, duration);
}

function updateTimeDisplay(currentTime, duration) {
    // You can add code here to update the UI with the current time and duration
    console.log(`Current Time: ${currentTime} / Duration: ${duration}`);
}

function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${padZero(minutes)}:${padZero(remainingSeconds)}`;
}

function padZero(number) {
    return number < 10 ? '0' + number : number;
}

// Initial load
loadTrack(currentTrackIndex);
audioPlayer.addEventListener('timeupdate', updateTime);
audioPlayer.addEventListener('ended', nextTrack);

// Add this line after the volumeSlider definition
volumeSlider.value = currentVolume; // Set the initial volume value in the UI
